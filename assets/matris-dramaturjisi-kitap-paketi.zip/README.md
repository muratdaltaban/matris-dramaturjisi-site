# MATRİS DRAMATURJİSİ — KİTAP PAKETİ
### Çürümenin Sanatı · Kitap I — Sürüm 1.0 · Haziran 2026

Murat Daltaban / DOT Theatre

## Paketin içindekiler

| Dosya | Ne işe yarar |
|---|---|
| **Matris-Dramaturjisi-Kitap.html** | E-kitap. Çift tıklayın, tarayıcıda açılır. Giriş ("Çürümenin Sanatı — Prensip 1: Gözün Krizi") + 11 bölüm + okuma listesi + kolofon. |
| **Matris-Dramaturjisi-AI.html** | Uygulama. Çift tıklayın, tarayıcıda açılır. AI analiz, 3D harita, karşılaştırma, otomatik kayıt, geri al. |
| **Matris-Dramaturjisi-Kullanim-Kilavuzu.pdf** | Kılavuz — okuma/yazdırma sürümü (45 sayfa, 20 bölüm). |
| **Matris-Dramaturjisi-Kullanim-Kilavuzu.docx** | Kılavuz — düzenlenebilir Word sürümü. |

Hiçbiri kurulum, üyelik veya internet bağlantısı istemez (yalnızca uygulamanın AI özellikleri internet + API anahtarı ister; kitabın fontları çevrimdışıyken sistem fontuna düşer, okunabilirlik bozulmaz).

## Kitap nasıl güncellenir?

Kitap "güncellenmeye açık" tasarlandı:

1. **Sürüm damgası** kapakta ve Kolofon bölümünde durur. Her güncellemede ikisi birden değiştirilir.
2. **Yeni bölüm eklemek**: HTML içinde her bölüm bir `<section class="chapter" id="...">` bloğudur. Yeni bölüm, mevcut bir bölümün kapanışından (`</section>`) sonra aynı kalıpla eklenir; İçindekiler listesine bir satır eklenir.
3. **Sürüm geçmişi** Kolofon'da tutulur — her değişiklik tarihli tek satır olarak işlenir.
4. Düzenleme için herhangi bir metin editörü yeter (Not Defteri dahil). Büyük güncellemeleri Claude'a tarif etmeniz de yeterli.

## Önerilen okuma sırası

Kitap (Giriş + Bölüm 1-3) → Uygulamada MACBETH örneğini açın → Kitap Bölüm 7'yi uygulamayla yan yana okuyun → gerisi serbest.

## Alıntı

Daltaban, Murat (2026). *Matris Dramaturjisi: Lehmann'dan Sonra Sahneyi Haritalamak*. Sürüm 1.0. İstanbul: DOT Theatre.

Lisans: CC BY-NC 4.0
